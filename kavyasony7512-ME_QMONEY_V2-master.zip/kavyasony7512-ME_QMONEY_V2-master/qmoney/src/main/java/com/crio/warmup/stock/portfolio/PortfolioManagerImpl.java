package com.crio.warmup.stock.portfolio;
import com.crio.warmup.stock.dto.AnnualizedReturn;
import com.crio.warmup.stock.dto.Candle;
import com.crio.warmup.stock.dto.PortfolioTrade;
import com.crio.warmup.stock.dto.TiingoCandle;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.management.RuntimeErrorException;
import org.springframework.web.client.RestTemplate;

public class PortfolioManagerImpl implements PortfolioManager {
  private RestTemplate restTemplate;

  private String token = "942153a713994b084ec1995cc0231192e150fe73";
  public String getToken() {
    return token;
  }

  protected PortfolioManagerImpl(RestTemplate restTemplate) {
    this.restTemplate = restTemplate;
  }

  private Comparator<AnnualizedReturn> getComparator() {
    return Comparator.comparing(AnnualizedReturn::getAnnualizedReturn).reversed();
  }

  public List<Candle> getStockQuote(String symbol, LocalDate from, LocalDate to)
      throws JsonProcessingException {
        if(from.isAfter(to)){
          throw new RuntimeErrorException(null);
        }

    String url = buildUri(symbol, from, to);
    TiingoCandle[] candles = this.restTemplate.getForObject(url, TiingoCandle[].class);
    return List.of(candles);
  }

  protected String buildUri(String symbol, LocalDate startDate, LocalDate endDate) {
            String url = "https://api.tiingo.com/tiingo/daily/" + symbol + "/prices?startDate="
        + startDate + "&endDate=" + endDate + "&token=" + getToken();
            return url;
  }

  private Double getOpeningPriceOnStartDate(List<Candle> candles) {
    return candles.get(0).getOpen();
  }

  private Double getClosingPriceOnEndDate(List<Candle> candles) {
    return candles.get(candles.size() - 1).getClose();
  }

  private AnnualizedReturn calculateAnnualizedReturnForATrade(LocalDate endDate, PortfolioTrade trade,  Double buyPrice, Double sellPrice) {
    double totalReturn  = (double)(sellPrice - buyPrice) / buyPrice;
    double year=(double)ChronoUnit.DAYS.between(trade.getPurchaseDate(), endDate)/365.0;
    double annualizedReturn = Math.pow(++totalReturn,1/year)-1;
  return new AnnualizedReturn(trade.getSymbol(), annualizedReturn, totalReturn);
      }

  @Override
  public List<AnnualizedReturn> calculateAnnualizedReturn(List<PortfolioTrade> portfolioTrades,
      LocalDate endDate) {
        List<AnnualizedReturn> annualizedReturns = new ArrayList<>();
        
        for (PortfolioTrade trade : portfolioTrades) {
         //  = new ArrayList<>();
          try {            
            List<Candle> candles =  getStockQuote(trade.getSymbol(), trade.getPurchaseDate(), endDate);
          
          AnnualizedReturn annualizedReturn = calculateAnnualizedReturnForATrade(endDate,
              trade, getOpeningPriceOnStartDate(candles), getClosingPriceOnEndDate(candles));
          annualizedReturns.add(annualizedReturn);
          }catch (JsonProcessingException e) {
            e.printStackTrace();
          }
        }
        Collections.sort(annualizedReturns, getComparator());
    return annualizedReturns ;
  }


//   @Override
// public List<AnnualizedReturn> calculateAnnualizedReturn(List<PortfolioTrade> portfolioTrades, LocalDate endDate) {
//     List<AnnualizedReturn> annualizedReturns = new ArrayList<>();
    
//     for (PortfolioTrade trade : portfolioTrades) {
//         List<Candle> candles = new ArrayList<>();
//         try {           
//             candles = getStockQuote(trade.getSymbol(), trade.getPurchaseDate(), endDate);
//         } catch (JsonProcessingException e) {
//             e.printStackTrace();
//         }

//         if (candles.isEmpty()) {
//             System.out.println("No data available for symbol: " + trade.getSymbol());
//             continue; 
//         }
//         AnnualizedReturn annualizedReturn = calculateAnnualizedReturnForATrade(endDate,
//             trade, getOpeningPriceOnStartDate(candles), getClosingPriceOnEndDate(candles));
//         annualizedReturns.add(annualizedReturn);
//     }
//     Collections.sort(annualizedReturns, getComparator());
//     return annualizedReturns;
// }
}
