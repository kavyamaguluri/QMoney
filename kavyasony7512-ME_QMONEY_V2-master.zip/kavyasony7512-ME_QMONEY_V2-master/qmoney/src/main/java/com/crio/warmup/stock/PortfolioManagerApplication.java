package com.crio.warmup.stock;

import com.crio.warmup.stock.dto.*;
import com.crio.warmup.stock.log.UncaughtExceptionHandler;


import com.crio.warmup.stock.dto.*;
import com.crio.warmup.stock.log.UncaughtExceptionHandler;
import com.crio.warmup.stock.portfolio.PortfolioManager;
import com.crio.warmup.stock.portfolio.PortfolioManagerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.management.RuntimeErrorException;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.cglib.core.Local;
import org.springframework.web.client.RestTemplate;


public class PortfolioManagerApplication {

  public static String token = "942153a713994b084ec1995cc0231192e150fe73";
  public static String getToken() {
    return token;
  }
  // ./gradlew run --args="trades.json 2020-01-01"
  public static List<String> mainReadQuotes(String[] args) throws IOException, URISyntaxException {
    List<PortfolioTrade> trades = readTradesFromJson(args[0]);
    List<TotalReturnsDto> dtos = new ArrayList<>();
    List<String> resultArray = new ArrayList<>();
    RestTemplate restTemplate = new RestTemplate();

    for (PortfolioTrade trade : trades) {
      List<Candle> candles = fetchCandles(trade, LocalDate.parse(args[1]), getToken());
      dtos.add(new TotalReturnsDto(trade.getSymbol(), getClosingPriceOnEndDate(candles)));
    }

    Collections.sort(dtos, new ClosingPriceComparator());
    for (TotalReturnsDto dto : dtos) {
      resultArray.add(dto.getSymbol());
    }
    return resultArray;
  }

  public static List<PortfolioTrade> readTradesFromJson(String filename)
      throws IOException, URISyntaxException {
    ObjectMapper objectMapper = getObjectMapper();
    File file = resolveFileFromResources(filename);
    PortfolioTrade[] trades = objectMapper.readValue(file, PortfolioTrade[].class);
    return Arrays.asList(trades);
  }

  public static String prepareUrl(PortfolioTrade trade, LocalDate endDate, String token) {
    if(trade.getPurchaseDate().isAfter(endDate)){
      throw new RuntimeErrorException(null);
    }
    String url = "https://api.tiingo.com/tiingo/daily/" + trade.getSymbol() + "/prices?startDate="
        + trade.getPurchaseDate() + "&endDate=" + endDate + "&token=" + token;
    return url;
  }

  public static List<String> mainReadFile(String[] args) throws IOException, URISyntaxException {
    List<PortfolioTrade> trades = readTradesFromJson(args[0]);
    List<String> symbols = new ArrayList<>();
    for (PortfolioTrade trade : trades) {
      symbols.add(trade.getSymbol());
    }
    return symbols;
  }

  private static void printJsonObject(Object object) throws IOException {
    Logger logger = Logger.getLogger(PortfolioManagerApplication.class.getCanonicalName());
    ObjectMapper mapper = new ObjectMapper();
    logger.info(mapper.writeValueAsString(object));
  }

  private static File resolveFileFromResources(String filename) throws URISyntaxException {
    return Paths.get(Thread.currentThread().getContextClassLoader().getResource(filename).toURI())
        .toFile();
  }

  static ObjectMapper getObjectMapper() {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    return objectMapper;
  }

  public static List<String> debugOutputs() {
    String valueOfArgument0 = "trades.json";
    String resultOfResolveFilePathArgs0 = "trades.json";
    String toStringOfObjectMapper = "ObjectMapper";
    String functionNameFromTestFileInStackTrace = "mainReadFile";
    String lineNumberFromTestFileInStackTrace = "";



    return Arrays.asList(
        new String[] {valueOfArgument0, resultOfResolveFilePathArgs0, toStringOfObjectMapper,
            functionNameFromTestFileInStackTrace, lineNumberFromTestFileInStackTrace});
  }

  static Double getOpeningPriceOnStartDate(List<Candle> candles) {
    return candles.get(0).getOpen();
  }

  public static Double getClosingPriceOnEndDate(List<Candle> candles) {
    return candles.get(candles.size() - 1).getClose();
  }

  public static List<Candle> fetchCandles(PortfolioTrade trade, LocalDate endDate, String token) {
    RestTemplate restTemplate = new RestTemplate();
    String url = prepareUrl(trade, endDate, token);
    TiingoCandle[] candles = restTemplate.getForObject(url, TiingoCandle[].class);
    return List.of(candles);
  }

  public static List<AnnualizedReturn> mainCalculateSingleReturn(String[] args)
      throws IOException, URISyntaxException {
    List<PortfolioTrade> trades = readTradesFromJson(args[0]);
    List<AnnualizedReturn> annualizedReturns = new ArrayList<>();
    LocalDate endDate = LocalDate.parse(args[1]);
    for (PortfolioTrade trade : trades) {
      List<Candle> candles = fetchCandles(trade, endDate, getToken());
      AnnualizedReturn annualizedReturn = calculateAnnualizedReturns(LocalDate.parse(args[1]),
          trade, getOpeningPriceOnStartDate(candles), getClosingPriceOnEndDate(candles));
      annualizedReturns.add(annualizedReturn);
    }
    Collections.sort(annualizedReturns);
    return annualizedReturns;
  }

  public static AnnualizedReturn calculateAnnualizedReturns(LocalDate endDate,
      PortfolioTrade trade,  Double buyPrice, Double sellPrice) {
       Double totalReturns = (sellPrice * trade.getQuantity() - buyPrice * trade.getQuantity()) / (buyPrice * trade.getQuantity());
       long numOfDays = ChronoUnit.DAYS.between(trade.getPurchaseDate(), endDate);
       Double numOfyears = numOfDays * 1.0/365;      
       Double annualizedReturns = Math.pow((1+ totalReturns),(1.0 / numOfyears)) - 1.0; 
       return new AnnualizedReturn(trade.getSymbol(), annualizedReturns, totalReturns);
      }

  public static List<AnnualizedReturn> mainCalculateReturnsAfterRefactor(String[] args)
      throws Exception {
       String file = args[0];
       LocalDate endDate = LocalDate.parse(args[1]);
       List<PortfolioTrade> trades = readTradesFromJson(file);
       PortfolioManager portfolioManager = PortfolioManagerFactory.getPortfolioManager(new RestTemplate());
       return portfolioManager.calculateAnnualizedReturn(trades, endDate);
  }


  public static void main(String[] args) throws Exception {
    Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler());
    ThreadContext.put("runId", UUID.randomUUID().toString());
    // printJsonObject(mainReadQuotes(args));
    // printJsonObject(mainCalculateSingleReturn(args));
    printJsonObject(mainCalculateReturnsAfterRefactor(args));

  }

}


class ClosingPriceComparator implements Comparator<TotalReturnsDto> {
  @Override
  public int compare(TotalReturnsDto dto1, TotalReturnsDto dto2) {
    if (dto1.getClosingPrice() > dto2.getClosingPrice()) {
      return 1;
    } else if (dto1.getClosingPrice() < dto2.getClosingPrice()) {
      return -1;
    }
    return 0;
  }
}

